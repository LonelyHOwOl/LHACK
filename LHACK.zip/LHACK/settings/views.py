from django.shortcuts import render

#
def index(request):
    return render(request, 'settings/index.html', {})

def account(request):
    return render(request, 'settings/account.html', {'title':'Аккаунт'})

def update(request):
    return render(request, 'settings/update.html', {'title':'Обновления'})