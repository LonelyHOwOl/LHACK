from django.urls import path
from .import views



urlpatterns = [
    path('', views.index, name='settings'),
    path('account/', views.account, name='account'),
    path('update/', views.update, name='update'),
    

]