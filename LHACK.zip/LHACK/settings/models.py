from django.db import models


from django.db import models

class Setting(models.Model):
    name = models.CharField(max_length=100)
    value = models.TextField()

    def str(self):
        return self.name
