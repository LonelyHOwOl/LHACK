import json
import asyncio
from channels.generic.websocket import AsyncWebsocketConsumer

from django.conf import settings
import SoapySDR
from SoapySDR import *
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os


Ns = 10000
buff = np.zeros( Ns,dtype= np.complex64)
sr = 0

class SpectConsumer(AsyncWebsocketConsumer):


    def __init__(self, *args, **kwargs):
        super().__init__(args, **kwargs)
        self.hackrf = SoapySDR.Device("driver=hackrf")
        self.is_running = False
        self.rx_stream = None
        self.transmission_task = None


    async def connect(self):
        await self.accept()
        print("Соеденение с HackRF установлено!")

    async def stop_transmission(self):
        self.is_running = False
        if self.rx_stream:
            self.hackrf.deactivateStream(self.rx_stream)
            self.hackrf.closeStream(self.rx_stream)
            print("Канал закрыт!")
            self.rx_stream = None
            
        if self.transmission_task:
            self.transmission_task.cancel()
            try:
                await self.transmission_task
            except asyncio.CancelledError:
                pass
            self.transmission_task = None

    async def disconnect(self, close_code):
        await self.stop_transmission()

    async def specterogramm_loop(self, Centre_freq, Sample_rate, Gain_rate):
        Centre_freq1 = int(Centre_freq) * 1_000_000  
        Sample_rate1 = int(Sample_rate) * 1_000_000  
        gain = float(Gain_rate)  

        if self.rx_stream is not None:
            print("Поток уже открыт. Закрываем его перед открытием нового.")
            self.hackrf.deactivateStream(self.rx_stream)
            self.hackrf.closeStream(self.rx_stream)
            self.rx_stream = None
        
        self.rx_stream = self.hackrf.setupStream(SOAPY_SDR_RX, SOAPY_SDR_CF32,[0])
        self.hackrf.activateStream(self.rx_stream)
        self.hackrf.setSampleRate(SOAPY_SDR_RX, 0, Sample_rate1)  # Установите ширину полосы
        self.hackrf.setFrequency(SOAPY_SDR_RX, 0, Centre_freq1)
        self.hackrf.setGain(SOAPY_SDR_RX, 0, gain)
        
        while self.is_running:
           
            sr = self.hackrf.readStream(self.rx_stream, [buff], Ns)

            
            print(sr)

            if sr.ret < 0:
                if sr.ret == -4:  # Проверка на переполнение
                    self.hackrf.deactivateStream(self.rx_stream)
                    self.hackrf.closeStream(self.rx_stream)
                    self.rx_stream = None  # Обнуляем поток

                    # Запускаем метод снова
                    await self.specterogramm_loop(Centre_freq, Sample_rate, Gain_rate)
                    return
                    print("Переполнение буфера! Увеличьте задержку или уменьшите размер буфера.")
                else:
                    print(f"Error reading stream: {sr.ret} - {SoapySDR.errToStr(sr.ret)}")
            else:
                print(f"Samples received: {sr.ret}")

            await asyncio.sleep(0.1)
            plt.ion() 
            plt.clf()
            plt.figure(figsize=(6, 4))
            Pxx, freqs, bins, im = plt.specgram(buff, NFFT=1024, Fs=Sample_rate1, noverlap=512)
            plt.imshow(10*np.log10(Pxx),aspect='auto',
            extent = [bins[-1],bins[0],freqs[0],freqs[-1]], origin='lower')
            plt.ylim(0, Sample_rate1 / 2)  # Ограничиваем частотный диапазон
            plt.tight_layout()
            plt.gcf().patch.set_facecolor('#2b2a2a')  # цвет фона фигуры
            plt.gca().set_facecolor('#2b2a2a')         # цвет фона осей
            
            plt.colorbar(label='Intensity')
            
            image_path = os.path.join(settings.MEDIA_ROOT, 'spectrogram.png')
            plt.savefig(image_path,  facecolor='#2b2a2a')  # Сохранение спектрограммы как изображения
            plt.close()
            await self.send(text_data=json.dumps({
                    'spectrum_image': image_path,
              
                }))
            
            await asyncio.sleep(0.000001)  # Небольшая задержка для избежания перегрузки

    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        action = text_data_json['action']

        if action == 'start':
            frequency = text_data_json['frequency']
            bandwidth = text_data_json['bandwidth']
            moshnost = text_data_json['moshnost']
            
            self.is_running = True  # Запускаем передачу
            self.transmission_task = asyncio.create_task(self.specterogramm_loop(frequency, bandwidth, moshnost))

        elif action == 'stop':
            self.is_running = False
            sr = 0
            await self.stop_transmission() 
   

    async def disconnect(self, close_code):
           pass