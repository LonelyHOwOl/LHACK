import json
import asyncio
from channels.generic.websocket import AsyncWebsocketConsumer
from django.conf import settings
from gpiozero import LED
from time import sleep
import SoapySDR
from SoapySDR import *
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
import scipy.signal as sig
from collections import deque
from scipy.fftpack import fft, fftshift

class AnalyzeConsumer(AsyncWebsocketConsumer):
    def __init__(self, *args, **kwargs):
        super().__init__(args, **kwargs)
        self.hackrf = SoapySDR.Device("driver=hackrf")
        self.hackrf.setBandwidth(SOAPY_SDR_RX, 0, 20e6)
        self.is_running = False
        self.rx_stream = None
        self.Ns_value_history = 0
        self.spectrum_history = []
        self.waterfall_history = []  # Ограничиваем историю водопада
        self.transmission_task = None
        self.max_hold_spectrum = None
        self.calc_spectrum = None
        self.Ns = 5000
        self.led_blue = LED(17)
        
    async def connect(self):
        await self.accept()
        print("Соединение с HackRF установлено!")

    async def stop_transmission(self):
        self.is_running = False
        #self.led_blue.off()
        if self.rx_stream:
            self.buff2 = np.zeros(self.Ns, dtype=np.complex64)
            self.hackrf.deactivateStream(self.rx_stream)
            self.hackrf.closeStream(self.rx_stream)
            print("Канал закрыт!")
            self.rx_stream = None
            
        if self.transmission_task:
            self.transmission_task.cancel()
            try:
                await self.transmission_task
            except asyncio.CancelledError:
                pass
            self.transmission_task = None

    async def disconnect(self, close_code):
        await self.stop_transmission()

    async def spectAnalyse_loop(self, Centre_freq, Sample_rate, Gain_rate, RBW_value, Ns_value):
        Centre_freq1 = int(Centre_freq) * 1e6 
        Sample_rate1 = int(Sample_rate) * 1e6 
        gain = float(Gain_rate)
        buff2 = np.zeros(Ns_value, dtype=np.complex64)
        
          # Сброс истории водопада
        if self.Ns_value_history != Ns_value:
            self.spectrum_history = []
            self.waterfall_history = []

        print(self.Ns_value_history,' ',Ns_value)
        if self.rx_stream is not None:
            print("Поток уже открыт. Закрываем его перед открытием нового.")
            self.hackrf.deactivateStream(self.rx_stream)
            self.hackrf.closeStream(self.rx_stream)
            self.rx_stream = None
       
      
        self.Ns_value_history = Ns_value
        self.hackrf.setSampleRate(SOAPY_SDR_RX, 0, Sample_rate1)
        #self.hackrf.setBandwidth(SOAPY_SDR_RX, 0, Sample_rate1)
        self.hackrf.setFrequency(SOAPY_SDR_RX, 0, Centre_freq1)
        self.hackrf.setGain(SOAPY_SDR_RX, 0, gain)
        self.rx_stream = self.hackrf.setupStream(SOAPY_SDR_RX, SOAPY_SDR_CF32, [0])
        self.hackrf.activateStream(self.rx_stream)
        self.x_plot = Sample_rate1 / 2
        
        while self.is_running:
            #self.led_blue.on()
            try:
                sr = self.hackrf.readStream(self.rx_stream, [buff2], Ns_value)

                if sr.ret < 0:
                    if sr.ret == -4:  # Проверка на переполнение
                        self.hackrf.deactivateStream(self.rx_stream)
                        self.hackrf.closeStream(self.rx_stream)
                        self.rx_stream = None
                        await self.spectAnalyse_loop(Centre_freq, Sample_rate, Gain_rate, RBW_value, Ns_value)
                        return
                    else:
                        print(f"Error reading stream: {sr.ret} - {SoapySDR.errToStr(sr.ret)}")
                else:
                    print(f"Samples received: {sr.ret}")

            except Exception as e:
                print(f"Device read error: {str(e)}")
                await asyncio.sleep(0.2)
                continue

            spectrum = fftshift(fft(buff2)/5050)
            #freqs = np.fft.fftshift(np.fft.fftfreq(len(buff2), 1 / Sample_rate1))
            f = np.arange(Centre_freq1 - self.x_plot, Centre_freq1 + self.x_plot, Sample_rate1 / self.Ns_val )
            # Добавляем данные в историю водопада
            power_spectrum = RBW_value * np.log10(np.abs(spectrum) + 1e-10)
            self.waterfall_history.append(power_spectrum)

           
            plt.clf()
            fig = plt.figure(figsize=(9, 5), facecolor='black')
            ax_spectrum = fig.add_subplot(2, 1, 1)
        
            if self.is_max_hold:
                if self.max_hold_spectrum is None:
                    self.max_hold_spectrum = np.abs(spectrum)
                else:
                    self.max_hold_spectrum = np.maximum(self.max_hold_spectrum, np.abs(spectrum))
                spectrum_data = RBW_value * np.log10(self.max_hold_spectrum)
                ax_spectrum.plot(f, spectrum_data, label='Max Hold')
            elif self.is_calc_spectrum:
                self.spectrum_history.append(np.abs(spectrum))
                if len(self.spectrum_history) > 10:
                    self.spectrum_history.pop(0)
                averaged_spectrum = np.mean(self.spectrum_history, axis=0)
                filtredSpectrum = sig.savgol_filter(np.abs(averaged_spectrum), 3, 1)
                spectrum_data = RBW_value * np.log10(filtredSpectrum)
                ax_spectrum.plot(f, spectrum_data, label='Average', lw=1)
            else:
                spectrum_data = RBW_value * np.log10(np.abs(spectrum))
                ax_spectrum.plot(f, spectrum_data, label='Instant', lw=1)
                
            ax_spectrum.set_ylim([-100, -10])
            ax_spectrum.set_xlim(Centre_freq1 - self.x_plot, Centre_freq1 + self.x_plot)
            ax_spectrum.grid(color='white', linestyle='-', linewidth=0.1)
            ax_spectrum.set_facecolor('black')
            ax_spectrum.tick_params(axis='both', colors='cyan') 
            ax_waterfall = fig.add_subplot(2, 1, 2)
            ax_waterfall.tick_params(axis='both', colors='cyan')
            
            if len(self.waterfall_history) > 0:
                waterfall_data = np.array(self.waterfall_history)
                img = ax_waterfall.imshow(waterfall_data, aspect='auto', 
                                        extent=[Centre_freq1 - self.x_plot, Centre_freq1 + self.x_plot, 0, len(self.waterfall_history)],
                                        cmap='viridis', vmin=-100, vmax=-10)
                if len(self.waterfall_history) > 80:
                    self.waterfall_history.pop(0)

            
            
            ax_waterfall.set_facecolor('black')
            
            # Общие настройки
            fig.tight_layout()
            fig.patch.set_facecolor('#0e0b0b')
            
            # Сохранение изображения
            image_path = os.path.join(settings.MEDIA_ROOT, 'spectrogram_analyze.png')
            plt.savefig(image_path, facecolor='#0e0b0b')
            plt.close(fig)
            
            # Отправка клиенту
            await self.send(text_data=json.dumps({
                'spectrum_image': image_path,
            }))
            
            await asyncio.sleep(0.03)

    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        action = text_data_json['action']

        if action == 'start' and not self.is_running:
            frequency = text_data_json['frequency']
            bandwidth = text_data_json['bandwidth']
            moshnost = text_data_json['moshnost']
            hold_mode = text_data_json.get('hold_mode')
            RBW_info = text_data_json['RBW']
            attunation_info = text_data_json['attunation']
            
            if attunation_info and attunation_info.strip():
                try:
                    Ns_value = int(attunation_info)
                except ValueError:
                    Ns_value = 5000
            else:
                Ns_value = 5000

            if RBW_info and RBW_info.strip():
                try:
                    RBW_value = float(RBW_info)
                except ValueError:
                    RBW_value = 20.0
            else:
                RBW_value = 20.0

            self.is_RBW = RBW_value
            self.Ns_val = Ns_value
            self.is_max_hold = (hold_mode == 'max_hold')
            self.is_calc_spectrum = (hold_mode == 'calc_hold')
            
            print(f"Received hold_mode: {hold_mode}, self.calc_hold: {self.is_calc_spectrum}")
            print(f"Received hold_mode: {hold_mode}, self.is_max_hold: {self.is_max_hold}")
            
            self.is_running = True
            self.transmission_task = asyncio.create_task(
                self.spectAnalyse_loop(frequency, bandwidth, moshnost, RBW_value, Ns_value)
            )

        elif action == 'stop' and self.is_running:
            self.is_running = False
            self.max_hold_spectrum = None
            await self.stop_transmission()