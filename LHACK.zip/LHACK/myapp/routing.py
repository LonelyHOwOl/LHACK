from django.urls import re_path
from .Mute_Consumers import GushilkaConsumer 
from .Spect_Consumers import SpectConsumer
from .Analyze_Consumers import AnalyzeConsumer
from .WiFi_jamer_Consumers import WiFi_Jamer_Consumer
from .Phone_Jamer_Consumers import Phone_Jamer_Consumer


websocket_urlpatterns = [
    re_path('ws/index/$', SpectConsumer.as_asgi()),
    re_path('ws/generator/',GushilkaConsumer.as_asgi()),
    re_path('ws/identification/', AnalyzeConsumer.as_asgi()),
    re_path('ws/spoofing/',WiFi_Jamer_Consumer.as_asgi()),
    re_path('ws/pelengator/',Phone_Jamer_Consumer.as_asgi())

]