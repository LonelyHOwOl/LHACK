from channels.generic.websocket import AsyncWebsocketConsumer
import SoapySDR
from SoapySDR import *
from gpiozero import LED
import numpy as np
import asyncio
import json


buff_size = 40000
std_dev = 30000

class GushilkaConsumer(AsyncWebsocketConsumer):
    
    def __init__(self, *args, **kwargs):
        super().__init__(args, **kwargs)
        self.hackrf = SoapySDR.Device("driver=hackrf")
        self.num_samples = 20000
        self.is_running = False
        self.tx_stream = None
        self.transmission_task = None
        self.led_red = LED(27)

    async def connect(self):
        await self.accept()
        print("Соеденение с HackRF установлено!")
        # Инициализация устройства, если необходимо
    async def stop_transmission(self):
        self.is_running = False
        self.led_red.off()
        if self.tx_stream:
            self.hackrf.deactivateStream(self.tx_stream)
            self.hackrf.closeStream(self.tx_stream)
            print("Канал закрыт!")
            self.tx_stream = None
        if self.transmission_task:
            self.transmission_task.cancel()
            try:
                await self.transmission_task
            except asyncio.CancelledError:
                pass
            self.transmission_task = None

    async def disconnect(self, close_code):
        await self.stop_transmission()

    async def send_gauss_loop(self, Centre_freq, Sample_rate, Gain_rate):
        self.hackrf = SoapySDR.Device("driver=hackrf")
        Centre_freq1 = int(Centre_freq) * 1_000_000  
        Sample_rate1 = int(Sample_rate) * 1_000_000  
        gain = float(Gain_rate)
        print("Канал открыт!")
        self.led_red.on()
        
        self.tx_stream = self.hackrf.setupStream(SOAPY_SDR_TX, SOAPY_SDR_CF32, [0])
        self.hackrf.activateStream(self.tx_stream)
        self.hackrf.setSampleRate(SOAPY_SDR_TX, 0, Sample_rate1)
        self.hackrf.setFrequency(SOAPY_SDR_TX, 0, Centre_freq1)
        self.hackrf.setGain(SOAPY_SDR_TX, 0, gain)


        while self.is_running:
            buff = np.random.normal(0, std_dev, size=buff_size) + 1j * np.random.normal(0, std_dev, size=buff_size)
            buff = buff.astype(np.complex64)

            size = min(buff.size, self.num_samples)
            print(buff)
            self.sr = self.hackrf.writeStream(self.tx_stream, [buff], size*20)
            print("передача выполнена")
            await asyncio.sleep(0.000000001)  # Небольшая задержка для избежания перегрузки

    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        action = text_data_json['action']

        if action == 'start' and not self.is_running:
            frequency = text_data_json['frequency']
            bandwidth = text_data_json['bandwidth']
            moshnost = text_data_json['moshnost']
            self.is_running = True
            self.transmission_task = asyncio.create_task(self.send_gauss_loop(frequency, bandwidth, moshnost))

        elif action == 'stop' and self.is_running:
            self.is_running = False
            await self.stop_transmission() 