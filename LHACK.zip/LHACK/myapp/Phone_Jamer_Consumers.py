import json
import asyncio
from channels.generic.websocket import AsyncWebsocketConsumer
import SoapySDR
from SoapySDR import *
import numpy as np
import random


#Phone_freqs = [795e6,810e6,955e6,2115e6,2125e6,2145e6,2165e6,2685e6,1810e6,1820e6,1810e6,1820e6,1810e6,1820e6,2115e6,2125e6,2145e6,2165e6,2685e6,2115e6,2125e6,2145e6,2165e6,2685e6]
Phone_freqs = [1815e6,2685e6,450e6,800e6]
buff_size = 40000
std_dev = 10000 
limit_count = 10
Centre_freq1 = Phone_freqs[0]
Sample_rate1 =  20e6 
gain = 60

hackrf = SoapySDR.Device("driver=hackrf")

class Phone_Jamer_Consumer(AsyncWebsocketConsumer):

    def __init__(self, *args, **kwargs):
        super().__init__(args, **kwargs)
        self.hackrf = SoapySDR.Device("driver=hackrf")
        self.num_samples = 20000
        self.limit_count=100
        self.freq_cen = random.choice(Phone_freqs)
        self.is_running = False
        self.tx_stream = None
        self.transmission_task = None

    async def connect(self):
        await self.accept()
        print("Соеденение с HackRF установлено!")
        
    async def stop_transmission(self):
        self.is_running = False
        if self.tx_stream:
            self.buff = np.zeros(self.num_samples,dtype= np.complex64)
            self.hackrf.deactivateStream(self.tx_stream)
            self.hackrf.closeStream(self.tx_stream)
            print("Канал закрыт!")
            self.tx_stream = None
        if self.transmission_task:
            self.transmission_task.cancel()
            try:
                await self.transmission_task
            except asyncio.CancelledError:
                pass
            self.transmission_task = None

    async def disconnect(self, close_code):
        await self.stop_transmission()

  

    async def Phone_jamer_loop(self,freq):
        print("запускаем джаммер wifi")
        
        
        self.tx_stream = self.hackrf.setupStream(SOAPY_SDR_TX, SOAPY_SDR_CF32, [0])
        self.hackrf.activateStream(self.tx_stream)
        self.hackrf.setFrequency(SOAPY_SDR_TX, 0, freq)
        self.hackrf.setSampleRate(SOAPY_SDR_TX, 0, Sample_rate1)
        self.hackrf.setGain(SOAPY_SDR_TX, 0, gain)
        
        self.buff = np.random.normal(0, std_dev, size=buff_size) + 1j * np.random.normal(0, std_dev, size=buff_size)
        self.high_freq_noise = np.random.normal(0, std_dev, size=buff_size) * np.sin(2 * np.pi * np.random.uniform(0.1, 1, buff_size) * np.arange(buff_size))
        self.buff = (self.buff + self.high_freq_noise).astype(np.complex64) 

        while self.is_running:  
  
            

            count =0
            while count <= self.limit_count:
                count+=1
                print(self.freq_cen )
                size = min(self.buff.size, self.num_samples)
                print(self.buff) 
                self.hackrf.setFrequency(SOAPY_SDR_TX, 0, self.freq_cen )
                self.sr = self.hackrf.writeStream(self.tx_stream, [self.buff], size*20)
                print("передача выполнена")
                await asyncio.sleep(0.00000001) 
                if count == self.limit_count:
                    self.freq_cen  = random.choice(Phone_freqs)

                    
            

    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        action = text_data_json['action']

        if action == 'start':
          
            self.is_running = True  # Запускаем передач
            self.transmission_task = asyncio.create_task(self.Phone_jamer_loop(Centre_freq1))

        elif action == 'stop':
            self.is_running = False
            await self.stop_transmission() 