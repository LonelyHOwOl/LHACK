import json
import asyncio
from channels.generic.websocket import AsyncWebsocketConsumer
import SoapySDR
from SoapySDR import *
import numpy as np
import random


Phone_freqs = [2420e6,2430e6,2440e6,2450e6,2460e6]
buff_size = 40000
std_dev = 50000 
limit_count = 30
Centre_freq1 = Phone_freqs[0]
Sample_rate1 =  20e6 
gain = 60

hackrf = SoapySDR.Device("driver=hackrf")

class WiFi_Jamer_Consumer(AsyncWebsocketConsumer):

    def __init__(self, *args, **kwargs):
        super().__init__(args, **kwargs)
        self.hackrf = SoapySDR.Device("driver=hackrf")
        self.num_samples = 80000
        self.freq_cen = random.choice(Phone_freqs)
        self.is_running = False
        self.tx_stream = None
        self.transmission_task = None

    async def connect(self):
        await self.accept()
        print("Соеденение с HackRF установлено!")
        
    async def stop_transmission(self):
        self.is_running = False
        if self.tx_stream:
            self.buff = np.zeros(self.num_samples,dtype= np.complex64)
            self.hackrf.deactivateStream(self.tx_stream)
            self.hackrf.closeStream(self.tx_stream)
            print("Канал закрыт!")
            self.tx_stream = None
        if self.transmission_task:
            self.transmission_task.cancel()
            try:
                await self.transmission_task
            except asyncio.CancelledError:
                pass
            self.transmission_task = None

    async def disconnect(self, close_code):
        await self.stop_transmission()

  

    async def Wifi_jamer_loop(self,freq):
        print("запускаем джаммер wifi")
        self.tx_stream = self.hackrf.setupStream(SOAPY_SDR_TX, SOAPY_SDR_CF32, [0])
        self.hackrf.activateStream(self.tx_stream)
        self.hackrf.setFrequency(SOAPY_SDR_TX, 0, freq)
        self.hackrf.setSampleRate(SOAPY_SDR_TX, 0, Sample_rate1)
        self.hackrf.setGain(SOAPY_SDR_TX, 0, gain)
        
        while self.is_running:  
  
            self.buff = np.random.normal(0, std_dev, size=buff_size) + 1j * np.random.normal(0, std_dev, size=buff_size)
            self.high_freq_noise = np.random.normal(0, std_dev, size=buff_size) * np.sin(2 * np.pi * np.random.uniform(0.1, 1, buff_size) * np.arange(buff_size))
            self.buff = (self.buff + self.high_freq_noise).astype(np.complex64) 

            count =0
            while count <= self.limit_count:
                count+=1
                print(self.freq_cen )
                size = min(self.buff.size, self.num_samples)
                print(self.buff) 
                self.hackrf.setFrequency(SOAPY_SDR_TX, 0, self.freq_cen )
                self.sr = self.hackrf.writeStream(self.tx_stream, [self.buff], size*20)
                print("передача выполнена")
                await asyncio.sleep(0.00000001) 
                if count == self.limit_count:
                    self.freq_cen  = random.choice(Phone_freqs)

                    
            

    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        action = text_data_json['action']

        if action == 'start':
            latitude_info = text_data_json['latitude']
            self.is_running = True  # Запускаем передачу

            if latitude_info and latitude_info.strip():
                try:
                    latitude_value = int(latitude_info)
                except ValueError:
                    latitude_value = 30 
            else:
                latitude_value = 30

            self.limit_count = latitude_value

            self.transmission_task = asyncio.create_task(self.Wifi_jamer_loop(Centre_freq1))

        elif action == 'stop':
            self.is_running = False
            await self.stop_transmission() 