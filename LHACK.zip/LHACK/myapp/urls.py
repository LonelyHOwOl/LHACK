from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from .Mute_Consumers import GushilkaConsumer
from .Spect_Consumers import SpectConsumer
from .Analyze_Consumers import AnalyzeConsumer
from .WiFi_jamer_Consumers import WiFi_Jamer_Consumer
from .Phone_Jamer_Consumers import Phone_Jamer_Consumer


urlpatterns = [
    path('admin/', admin.site.urls),
    path('settings/', include ('settings.urls')),
    path('MyUserModel/', include('MyUserModel.urls')),
    path('', include('main.urls'))
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


websocket_urlpatterns = [
    path('ws/generator/', GushilkaConsumer.as_asgi()),
    path('ws/index/', SpectConsumer.as_asgi()),
    path('ws/identification/', AnalyzeConsumer.as_asgi()),
    path('ws/spoofing/',WiFi_Jamer_Consumer.as_asgi()),
    path('ws/pelengator/',Phone_Jamer_Consumer.as_asgi())
]