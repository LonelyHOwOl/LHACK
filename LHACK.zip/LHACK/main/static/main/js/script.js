document.addEventListener('DOMContentLoaded', function () {
    // Получаем кнопку и тост
    const showToastBtn = document.getElementById('showToastBtn');
    const liveToast = document.getElementById('liveToast');

    // Добавляем обработчик события на кнопку
    showToastBtn.addEventListener('click', function () {
        const toast = new bootstrap.Toast(liveToast, {
            autohide: true,  // Уведомление будет скрываться автоматически
            delay: 10000     // Время показа уведомления (10 секунд)
        });

        toast.show(); // Показываем уведомление
    });
});