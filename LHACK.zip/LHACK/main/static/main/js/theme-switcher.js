// Проверка сохраненной темы при загрузке страницы
document.addEventListener("DOMContentLoaded", () => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme) {
        setTheme(savedTheme);
    } else {
        // Установка автоматической темы по умолчанию
        setTheme(window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    }

    // Обновление темы при изменении системных настроек (автоматический режим)
    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
        if (localStorage.getItem("theme") === "auto") {
            setTheme(e.matches ? "dark" : "light");
        }
    });
});

// Функция для смены темы
function setTheme(theme) {
    const root = document.documentElement; // Ссылка на HTML-элемент
    if (theme === "dark") {
        root.setAttribute("data-theme", "dark");
    } else if (theme === "light") {
        root.setAttribute("data-theme", "light");
    } else {
        root.removeAttribute("data-theme");
    }
    localStorage.setItem("theme", theme);
}

// Добавление обработчиков событий для кнопок
document.querySelectorAll(".theme-button").forEach(button => {
    button.addEventListener("click", () => {
        setTheme(button.dataset.theme);
    });
});