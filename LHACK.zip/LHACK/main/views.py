from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from .forms import JammerForm
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.conf import settings
#from .Hack_rf_Mute import Send_Gauss
#from .spectrogramm2 import spectrogramm
import numpy as np

import logging
import os


def index(request):
    return render(request, 'main/index.html', {'title':'Частотная соннограма'})

def identification(request):
    return render(request, 'main/identification.html', {'title':'Анализатор спектра'})

def generator(request):
    return render(request, 'main/generator.html', {'title':'Генератор помех'})

def pelengator(request):
    return render(request, 'main/pelengator.html', {'title':'Пеленгатор'})
    
def spoofing(request):
    return render(request, 'main/spoofing.html', {'title':'Джаммер Wifi'})

def datatransfer(request):
    return render(request, 'main/datatransfer.html', {'title':'Передача данных'})

def pelengator(request):
    return render(request, 'main/pelengator.html', {'title':'Джаммер сотовой связи'})


def example_view(request):
    messages.success(request, 'Сообщение отправлено успешно!')
    return redirect('/')

def toast_notification_view(request):
    return render(request, 'generator.html')

@csrf_exempt
def generator_view(request):
   
    return render(request, "main/generator.html")

@csrf_exempt
def spectrum_view(request):
  
    return render(request, 'main/index.html')
     

@csrf_exempt
def spoofing_view(request):

    return render(request, "spoofing.html")


logger = logging.getLogger(__name__)

def home_view(request):
    logger.debug("this is a debug message")
    logger.info("this is an info message")
    logger.warning("this is a warning message")
    logger.error("this is an error message")
    logger.critical("this is a critical message")

    return render(request, 'home.html')


