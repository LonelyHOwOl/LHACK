from django.urls import path, include
from . import views
from .views import generator_view, spectrum_view
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='home'),
    path('index/', spectrum_view, name ='spectrum_view'),
    path('identification', views.identification, name='identification'),
    path('generator/', views.generator, name='generator'),
    path('generator/view/', generator_view, name='generator_view'),
    path('pelengator/', views.pelengator, name='pelengator'),
    path('spoofing/', views.spoofing, name='spoofing'),
    path('datatransfer/', views.datatransfer, name='datatransfer'),
    path('settings/', include('settings.urls')),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
