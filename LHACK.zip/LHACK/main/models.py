from django.db import models

class JammerSettings(models.Model):
    frequency = models.FloatField("Опорная частота (Гц)")
    bandwidth = models.FloatField("Ширина полосы (Гц)")

    def str(self):
        return f"Частота: {self.frequency}, Ширина полосы: {self.bandwidth}"


class Coordinate(models.Model):
    latitude = models.FloatField("Ширина")
    longitude = models.FloatField("Долгота")

    def str(self):
        return f"Ширина: {self.latitude}, Долгота: {self.longitude}"