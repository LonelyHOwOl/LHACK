from django import forms
from .models import JammerSettings

class JammerForm(forms.Form):
    frequency = forms.FloatField(label='Опорная частота', required=True,
                                  widget=forms.NumberInput(attrs={'placeholder': 'Введите частоту'}))
    bandwidth = forms.FloatField(label='Ширина полосы', required=True,
                                  widget=forms.NumberInput(attrs={'placeholder': 'Введите ширину полосы'}))


class Coordinate (forms.Form):
    latitude = forms.FloatField(label='Ширина', required=True,
                                  widget=forms.NumberInput(attrs={'placeholder': 'Введите ширину'}))
    longitude = forms.FloatField(label='Долгота', required=True,
                                  widget=forms.NumberInput(attrs={'placeholder': 'Введите долготу'}))